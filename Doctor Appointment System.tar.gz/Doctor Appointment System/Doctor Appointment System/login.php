<?php
$account=$_GET["account"];
$username=$_GET["username"];
$password=$_GET["password"];
var $f=0; 
 $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die("Error ");
  }
  mysql_query("use rbnb");
if($account=='admin')
{
   $sql="select * from admin";
    $res=mysql_query($sql);
    while($row=mysql_fetch_array($res))
   {
       if(($row['name']==$username)&&($row['pasd']==$password))
         {
            $f=1;
          } 
    }
if($f==1)
{
echo"admin";
}
else
{
   echo"no";
}
}

if($account=='doctor')
{
    $res=mysql_query("select * from doctor");
    while($row=mysql_fetch_array($res))
   {
       if($row['dname']==$username && $row['dpasd']==$password)
         {
            $f=1;
            break;
          } 
    }
if($f==1)
echo"doctor";
else
   echo"no";
}



if($account=="patient")
{
    $res=mysql_query("select * from patient");
    while($row=mysql_fetch_array($res))
   {
       if($row['pname']==$username && $row['ppasd']==$password)
         {
            $f=1;
            break;
          } 
    }
if($f==1)
echo"patient";
else
   echo"no";
}



?>

