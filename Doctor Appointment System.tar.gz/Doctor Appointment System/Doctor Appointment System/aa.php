<?php
   $num = cal_days_in_month(CAL_GREGORIAN, 1, 20016);
   echo "There was $num days in Jan 20016";
?> 