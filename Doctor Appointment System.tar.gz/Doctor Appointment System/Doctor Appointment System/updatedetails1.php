<!DOCTYPE html>
<html>
<head>
<style>

ul{
list-style-type:none;
margin:0px;
padding:0px;
width:185px;
background-color:"blue";

}
li>a{
display:block;
color:white;
padding:5px 5px;
text-decoration:none;

}
li>a:hover{
background-color:white;
color:blue;
}





<!--
.style2 {
color: #FFFFFF
}
.style3 {
font-size: xx-large;
 font-weight: bold;
 font-family: Georgia, "Times New Roman", Times, serif;
  
}
.>


div.img{
     margin:5px;
     float:center;
       width:180px;
    }
h1{
        text-align:center;
        line-height:1.2;
}

img{
  width:100%;
}
</style>
</head>
<body background="">
<form method="POST" action="updatedetails.php">
<div class="img">
<img src="AAEAAQAAAAAAAAe9AAAAJDNjZTkzMjVlLWYyMGUtNGMzZi05ZGNmLTE3NDcwNzA4MzNiYw.jpg" align="center" style="background-size:cover;float:center;width:1519px; height:200px;">


<table width=1519px height="65" border="0" bordorcolor="blue">
  <tr>
    <td height="40" align="center" valign="middle" bordercolor="white" bgcolor="blue"> <div align="left" class="style2"><span class="style3"><font size="30">&nbsp;&nbsp;&nbsp;Doctor</span></div></td>
  </tr>
</table>



<table border="0" bgcolor="blue">

<tr>
<td><ul><li><a href="doctor1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>GiveAppointment</small></center></a></li></ul></td>
<td><ul><li><a href="viewdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Appointment</small></center></a></li></ul></td>
<td><ul><li><a href="updatedetails1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Update the Details </small></center></a></li></ul></td>
<td><ul><li><a href="addpatient1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Add Patient</small></center></a></li></ul></td>
<td><ul><li><a href="mainframe1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Log out</small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
</tr>

</table>


<table border="0">

<tr>
<td height="0" width="400"><img src="health_care_system.jpg" width="300" height="500">
</td>
<td width="700" height="300" align="center" bgcolor="blue">
<br><font size="5" color="white">&nbsp;&nbsp;Enter your phone no:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t1"><br><br>
<font color="white" size="7" align="center">Change your details:</font><br><br><br>
<br>
&nbsp;Hospital name:&nbsp;&nbsp;<input type="text" name="t2"><br>
Specialist:&nbsp;&nbsp;&nbsp;&nbsp;  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t3"><br>
&nbsp;Experiance:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t4">
<br>
Avialable time:<br>&nbsp;&nbsp;&nbsp;From:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t5">&nbsp;&nbsp;&nbsp;<br>To:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t6"><br>
<br><input type="submit" value="Add" width="10">

<input type="reset"></td>
<td height="0" width="400"><img src="doctor-appointment-concealed-carry.jpg" width="300" height="500"></td></tr>



</table>
<table border="0">
<tr>
<td bgcolor="blue" height="50" width="1500"><font size="3" color="white">&nbsp;&nbsp;&nbsp;@doctorappointmentsystem</td>
</tr>
</table>



</form>

</body>
</html>