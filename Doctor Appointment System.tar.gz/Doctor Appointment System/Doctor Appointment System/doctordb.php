<?php

 $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die('Error '.mysql_error());
  }
  else echo"connected";
  mysql_select_db('rbnb',$con) or die(mysql_error($con));

   $nm=$_POST["t1"];
   $emailid=$_POST["t2"];
   $address=$_POST["t3"];
   $city=$_POST["t4"];
   $hn=$_POST["t12"];
   $bdate=$_POST["t5"];
    $phno=$_POST["t6"];
 $sp=$_POST["t7"];
 $exp=$_POST["t8"];
  $pasw=$_POST["t9"];
$fromtime=$_POST["t10"];
$totime=$_POST["t11"];

  mysql_query("insert into  doctor values(NULL,'".$nm."','".$emailid."','".$address."','".$city."','".$bdate."','".$phno."','".$sp."','$exp','".$pasw."','$fromtime','$totime','".$hn."')");
echo"<br>registration succesfully";
echo"<br>click here to go login page";
echo"<a href='mainframe1.php'>login</a>";  
  ?>





