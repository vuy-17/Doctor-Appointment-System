<?php

  $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die('Error '.mysql_error());
  }
  else echo"connected";
  mysql_select_db('rbnb',$con) or die(mysql_error($con));

   $id=$_POST["t6"];
   $nm=$_POST["t1"];
   $add=$_POST["t2"];
   $eid=$_POST["t3"];
   $ph=$_POST["t4"];
   $pass=$_POST["t5"];


  mysql_query("insert into admin7 values(NULL,'".$nm."','".$add."','".$eid."','".$ph."','".$pass."')");
echo"<br>registration succesfully";
echo"<br>click here to go login page";
echo"<a href='mainframe1.php'>login</a>";
    
?>