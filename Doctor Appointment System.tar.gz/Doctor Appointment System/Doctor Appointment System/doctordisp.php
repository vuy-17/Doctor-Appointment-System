<!DOCTYPE html>
<html>
<head>
<style>


select{
   width:20%;
   padding:5px 15px;
  border:none;
border-radius:10px;
background-color:"white";
}


.form{
position:relative;
z-index:1;
background:rgba(7,40,195,0.8);
max-width:360px;
margin:0 auto 100px;
padding:45px;
text-align:center;
}

.form input{
 font-family:"Roboto",sans-serif;
outline:1;
background:#f2f2f2;
width:100%;
border=0;
margin:0 0 15px;
padding:10px;
box-sizing:bordor-box;
font-size:14px;
}


.form button{
 font-family:"Roboto",sans-serif;
text-transform:uppercase;
outline:0;
background:#4CAF50;
width:20%;
border=0;
margin:5 5 20px;
padding:10px;
box-sizing:bordor-box;
color:#FFFFFF;
font-size:20px;
cursor:pointer;
}

ul{
list-style-type:none;
margin:0px;
padding:0px;
width:184px;
background-color:"blue";

}
li>a{
display:block;
color:white;
padding:5px 5px;
text-decoration:none;

}
li>a:hover{
background-color:white;
color:blue;
}





<!--
.style2 {
color: #FFFFFF
}
.style3 {
font-size: xx-large;
 font-weight: bold;
 font-family: Georgia, "Times New Roman", Times, serif;
  
}
.>


div.img{
     margin:5px;
     float:center;
       width:180px;
    }
h1{
        text-align:center;
        line-height:1.2;
}

img{
  width:100%;
}
</style>
</head>
<body background="">
<form method="post" action="takeappointment.php">
<div class="img">
<img src="AAEAAQAAAAAAAAe9AAAAJDNjZTkzMjVlLWYyMGUtNGMzZi05ZGNmLTE3NDcwNzA4MzNiYw.jpg" align="center" style="background-size:cover;float:center;width:1510px; height:200px;">


<table width=1510px height="65" border="0" bordorcolor="blue">
  <tr>
    <td height="40" align="center" valign="middle" bordercolor="white" bgcolor="blue"> <div align="left" class="style2"><span class="style3"><font size="30">&nbsp;&nbsp;&nbsp;Admin</span></div></td>
  </tr>
</table>



<table border="0" bgcolor="blue">

<tr>
<td><ul><li><a href="admin1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Take Appointment</small></center></a></li></ul></td>
<td><ul><li><a href="takeappointmentdisp.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Appointment</small></center></a></li></ul></td>
<td><ul><li><a href="adddoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Add Doctor </small></center></a></li></ul></td>
<td><ul><li><a href="doctordisp.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Doctor</small></center></a></li></ul></td>
<td><ul><li><a href="addpatient.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Add Patient</small></center></a></ul></li>
</td>
<td><ul><li><a href="patientdisp.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Patient</small></center></a></ul></li>
</td>
<td><ul><li><a href="showfeedback.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Feedback</small></center></a></ul></li>
</td>
<td width="6"><ul><li><a href="mainframe1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Log out</small></center></a></ul></li>
</td>
</tr>

</table>

<table border="0" align="center">
<tr>
<td width="1600" height="0"  bgcolor="blue" bordercolor="white">
<?php
 $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die("Error ");
  }
  mysql_query("use rbnb");

   $sql="select * from doctor";
    $res=mysql_query($sql);
echo"<table border='1' bordercolor='white' align='center'>";
echo"<tr><font size='6' color='white' align='center'><b><center><br>Doctor Details:</b></font></tr>";
echo"<tr><th><font color='white' size='5'>Doctor id<th><font color='white' size='5'>Name<th><font color='white' size='5'>Email ID<th><font color='white' size='5'>Address<th><font color='white' size='5'>City<th><font color='white' size='5'>Birth date<th><font color='white' size='5'>Phone no<th><font color='white' size='5'>Specialist<th><font color='white' size='5'>Experiance<th>
<font color='white' size='5'>Password<th><font color='white' size='5'>From time<th><font color='white' size='5'>To time<th><font color='white' size='5'>Hospital name</th></tr>";

    while($row=mysql_fetch_array($res))
   {
  echo"<tr><td><font color='white' size='5'><center>".$row['daid']."<td><font color='white' size='5'>".$row['dname']."</td><td><font color='white' size='5'>".$row['demailid']."</td><td><font color='white' size='5'>".$row['daddr']."</td><td><font color='white' size='5'>".$row['dcity']."</td><td><font color='white' size='5'>".$row['dbdate']."</td><td><font color='white' size='5'>".$row['dphoneno']."</td><td><font color='white' size='5'><center>".$row['sp']."</td><td><font color='white' size='5'><center>".$row['exp']."</td><td><font color='white' size='5'>".$row['dpasd']."</td><td><font color='white' size='5'><center>".$row['fromtime']."</td><td><font color='white' size='5'><center>".$row['totime']."</td><td><font color='white' size='5'>".$row['hospital']."</font></td></tr><br>";
}
echo"</table>";
?>
</td></tr>
</table>
<table border="0">
<tr>
<td bgcolor="blue" height="50" width="1500"><font size="3" color="white">&nbsp;&nbsp;&nbsp;@doctorappointmentsystem</td>
</tr>
</table>
</form>
</body>
</html>