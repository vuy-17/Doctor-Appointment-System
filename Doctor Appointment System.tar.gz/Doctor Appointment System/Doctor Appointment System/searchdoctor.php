<!DOCTYPE html>
<html>
<head>
<style>

ul{
list-style-type:none;
margin:0px;
padding:0px;
width:185px;
background-color:"blue";

}
li>a{
display:block;
color:white;
padding:5px 5px;
text-decoration:none;

}
li>a:hover{
background-color:white;
color:blue;
}





<!--
.style2 {
color: #FFFFFF
}
.style3 {
font-size: xx-large;
 font-weight: bold;
 font-family: Georgia, "Times New Roman", Times, serif;
  
}
.>


div.img{
     margin:5px;
     float:center;
       width:180px;
    }
h1{
        text-align:center;
        line-height:1.2;
}

img{
  width:100%;
}
</style>
</head>
<body background="">
<div class="img">
<img src="AAEAAQAAAAAAAAe9AAAAJDNjZTkzMjVlLWYyMGUtNGMzZi05ZGNmLTE3NDcwNzA4MzNiYw.jpg" align="center" style="background-size:cover;float:center;width:1519px; height:200px;">


<table width="1519px" height="65" border="0" bordorcolor="blue">
  <tr>
    <td height="40" align="center" valign="middle" bordercolor="white" bgcolor="blue"> <div align="left" class="style2"><span class="style3"><font size="30">&nbsp;&nbsp;&nbsp;Patient</span></div></td>
  </tr>
</table>



<table border="0" bgcolor="blue">

<tr>
<td><ul><li><a href="searchdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Search Doctor</small></center></a></li></ul></td>
<td><ul><li><a href="patient1disp.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Appointment</small></center></a></li></ul></td>
<td><ul><li><a href="patient1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Take Appointment </small></center></a></li></ul></td>
<td><ul><li><a href="mainframe1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Log out</small></center></a></li></ul></td>
<td><ul><li><a href="searchdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="searchdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="searchdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="searchdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
</tr>

</table>


<table border="0">

<tr>
<td height="0" width="400"><img src="52765927f3ee11335925125b3fe7b0ce81b3e4c07a139.gif" width="200" height="200">
<img src="health_care_system.jpg" width="200" height="400">
</td>
<td width="800" height="300" align="center" bgcolor="blue">
<font color="white" size="6" align="center"><br><br>Find doctor here:</font><br>
<?php
 $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die("Error ");
  }
  mysql_query("use rbnb");

   $sql="select * from doctor";
    $res=mysql_query($sql);
echo"<table border='1' bordercolor='white' align='center'>";

echo"<tr><th><font color='white'>Doctor id<th><font color='white' >Name<th><font color='white'>Email ID<th><font color='white' >City<th><font color='white'>Specialist<th><font color='white' >Experiance<th><font color='white' >From time<th><font color='white' >To time<th><font color='white'>Hospital name</th></tr>";

    while($row=mysql_fetch_array($res))
   {
  echo"<tr><td><font color='white' ><center>".$row['daid']."<td><font color='white' >".$row['dname']."</td><td><font color='white' >".$row['demailid']."</td><td><font color='white' >".$row['dcity']."</td><td><font color='white'><center>".$row['sp']."</td><td><font color='white' ><center>".$row['exp']."</td><td><font color='white'><center>".$row['fromtime']."</td><td><font color='white' ><center>".$row['totime']."</td><td><font color='white'>".$row['hospital']."</font></td></tr><br>";
}
echo"</table>";
?>
















<td height="0" width="400"><img src="doctor-appointment-concealed-carry.jpg" width="300" height="600"></td></tr>
</table>


<table border="0">
<tr>
<td bgcolor="blue" height="50" width="1500"><font size="3" color="white">&nbsp;&nbsp;&nbsp;@doctorappointmentsystem</td>
</tr>
</table>

</body>
</html>