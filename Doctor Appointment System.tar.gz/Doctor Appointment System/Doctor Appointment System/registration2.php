<html>
<style>
body{
     background-image:linear-gradient(rgba(1,0,0,0.4),rgba(0,0,0,0.4)),url(images1.jpg);
 
    
    background-size:cover;
    background-position:center;
}
.form{
position:relative;
z-index:1;
background:rgba(7,40,195,0.8);
max-width:360px;
margin:150 auto 100px;
padding:45px;
text-align:center;
}

#button{
 font-family:"Roboto",sans-serif;
text-transform:uppercase;
outline:0;
background:#FFFFFF;
width:5%;
border=1;
margin:5 5 20px;
padding:10px;
box-sizing:bordor-box;
color:#F0FFFF;
font-size:20px;
cursor:pointer;
 display:block;
     line-height:2em;
     text-align:center;
      text-decoration:none;
     border-radius:5px;
   width:6em;
   border:2px solid blue;
   background:#0000FF;
   border-radius:5px;
 
}
#button{
}
a{
     display:block;
     width:100%;
     line-height:2em;
     text-align:center;
      text-decoration:none;
     border-radius:5px;
 }
a.hover{
  color:white;
  background:#FFFFFF;
}
</style>
<body>
<form>

<div class="login-page">
<div class="form">
<form class="register-form">

<font size="15
" align="center" color="white"><b>&nbsp;Register here:&nbsp;&nbsp;&nbsp;&nbsp;<br>
<tr><td><font size="5" color="white">Account type</td></tr><br>
</form>
</div>
</div>
<table align="center" border="0"><tr><td>
<div id="button"><a href="admin2.php"><font color="white">Admin</a></div></td><td>
<div id="button"><a href="doctor2.php"><font color="white">Doctor</a></div></td><td><div id="button"><a href="patient2.php"><font color="white">Patient</a></div></td></tr></table>

</form>
</body>

</html>