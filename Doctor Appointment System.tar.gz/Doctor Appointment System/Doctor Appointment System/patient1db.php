<!DOCTYPE html>
<html>
<head>
<style>

select{
   width:20%;
   padding:5px 15px;
  border:none;
border-radius:10px;
background-color:"white";
}

ul{
list-style-type:none;
margin:0px;
padding:0px;
width:185px;
background-color:"blue";

}
li>a{
display:block;
color:white;
padding:5px 5px;
text-decoration:none;

}
li>a:hover{
background-color:white;
color:blue;
}





<!--
.style2 {
color: #FFFFFF
}
.style3 {
font-size: xx-large;
 font-weight: bold;
 font-family: Georgia, "Times New Roman", Times, serif;
  
}
.>


div.img{
     margin:5px;
     float:center;
       width:180px;
    }
h1{
        text-align:center;
        line-height:1.2;
}

img{
  width:100%;
}
</style>
</head>
<body background="">


<div class="img">
<img src="AAEAAQAAAAAAAAe9AAAAJDNjZTkzMjVlLWYyMGUtNGMzZi05ZGNmLTE3NDcwNzA4MzNiYw.jpg" align="center" style="background-size:cover;float:center;width:1519px; height:200px;">


<table width="100%" height="65" border="0" bordorcolor="blue">
  <tr>
    <td height="40" align="center" valign="middle" bordercolor="white" bgcolor="blue"> <div align="left" class="style2"><span class="style3"><font size="30">&nbsp;&nbsp;&nbsp;Patient</span></div></td>
  </tr>
</table>



<table border="0" bgcolor="blue">

<tr>
<td><ul><li><a href="searchdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Search Doctor</small></center></a></li></ul></td>
<td><ul><li><a href="patient1disp.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Appointment</small></center></a></li></ul></td>
<td><ul><li><a href="patient1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Take Appointment </small></center></a></li></ul></td>
<td><ul><li><a href="mainframe1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Log out</small></center></a></li></ul></td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
</tr>

</table>
<table border="0">

<tr>
<td height="0" width="450"><img src="health_care_system.jpg" width="300" height="500">
</td>
<td width="900" height="300" align="center" bgcolor="blue">


<?php
$con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die('Error '.mysql_error());
 }
 mysql_select_db('rbnb',$con) or die(mysql_error($con));
$pname=$_POST["t1"];
$did=$_POST["t8"];
$dname=$_POST["t2"];
$symp=$_POST["t3"];
$date=$_POST["t4"];
$timing=$_POST["timing"];
$dt=$date.":".$timing;
 $ft=0;
$tt=0;
$tim=0;
$f=0;
$sql="select * from doctor";
    $res=mysql_query($sql);
    while($row=mysql_fetch_array($res))
   {
       if($row['daid']==$did)
         {
            $fromtime=$row['fromtime'];
             $totime=$row['totime'];
            if($fromtime>=8&&$fromtime<=12)
                $ft=$fromtime;
            if($totime>=9&&$totime<=12)
                $tt=$totime;
             if($timing>=8&&$timing<=12)
                $tim=$timing;
             if($fromtime=="1")
                   $ft=13;
              if($fromtime=="2")
                   $ft=14;
              if($fromtime=="3")
                   $ft=15;
              if($fromtime=="4")
                   $ft=16;
              if($fromtime=="5")
                   $ft=17;
              if($fromtime=="6")
                   $ft=18;
              if($fromtime=="7")
                   $ft=19;
              if($totime=="1")
                   $tt=13;
              if($totime=="2")
                   $tt=14;
              if($totime=="3")
                   $tt=15;
              if($totime=="4")
                   $tt=16;
              if($totime=="5")
                   $tt=17;
              if($totime=="6")
                   $tt=18;
              if($totime=="7")
                   $tt=19;
              if($totime=="8")
                   $tt=20;
               if($timing=="1")
                   $tim=13;
              if($timing=="2")
                   $tim=14;
              if($timing=="3")
                   $tim=15;
              if($timing=="4")
                   $tim=16;
              if($timing=="5")
                   $tim=17;
              if($timing=="6")
                   $tim=18;
              if($timing=="7")
                   $tim=19;
           if(($tim>=$ft)&&($tim<$tt))               
                {
                 $sqlt="select * from takeapp";
             $req=mysql_query($sqlt);
   while($row=mysql_fetch_array($req))
   {
       if(($row['dname']==$dname)&&($row['dt']==$dt))
         {
            $f=1;
          } 
    }
                    if($f==0) 
                 {
                    mysql_query("insert into takeapp values('".$pname."',$did,'".              $dname."','".$symp."','".$dt."')");
                                          echo"<br><font size='10' color='white' align='center'>Appointment confirmed";
              }
                  if($f==1)
                  {   
                         echo"<br><font size='10' color='white' align='center'>Appointment already fixed.....try another ";
                    }
                }
      else
                          echo"<br><font size='10' color='white' align='center'>Failed...Try         Again";
  
            } 
    }


?>


</td>
<td width="500" height="300">
<img src="doctor-appointment-concealed-carry.jpg" width="200" height="500">



</td>

</tr>

</table>
<table border="0">
<tr>
<td bgcolor="blue" height="50" width="1500"><font size="3" color="white">&nbsp;&nbsp;&nbsp;@doctorappointmentsystem</td>
</tr>
</table>
</form>
</body>
</html>





