<?php
   $nm=$_POST["t1"];
   $add=$_POST["t2"];
   $eid=$_POST["t3"];
   $ph=$_POST["t4"];
   $pass=$_POST["t5"];


  $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die("Error ");
  }
  mysql_query("use admin");
  mysql_query("insert into  admin1 values('$nm','$add','$eid',$ph,'$pass')");
  echo("Registeration successfully...");
  echo("<a href='admin2.php'>BACK </a>");
?>