<!DOCTYPE html>
<html>
<head>
<style>

select{
   width:20%;
   padding:5px 15px;
  border:none;
border-radius:10px;
background-color:"white";
}

ul{
list-style-type:none;
margin:0px;
padding:0px;
width:185px;
background-color:"blue";

}
li>a{
display:block;
color:white;
padding:5px 5px;
text-decoration:none;

}
li>a:hover{
background-color:white;
color:blue;
}





<!--
.style2 {
color: #FFFFFF
}
.style3 {
font-size: xx-large;
 font-weight: bold;
 font-family: Georgia, "Times New Roman", Times, serif;
  
}
.>


div.img{
     margin:5px;
     float:center;
       width:180px;
    }
h1{
        text-align:center;
        line-height:1.2;
}

img{
  width:100%;
}
</style>
</head>
<body background="">
<form method="post" action="patient1db.php">
<div class="img">
<img src="AAEAAQAAAAAAAAe9AAAAJDNjZTkzMjVlLWYyMGUtNGMzZi05ZGNmLTE3NDcwNzA4MzNiYw.jpg" align="center" style="background-size:cover;float:center;width:1519px; height:200px;">


<table width="100%" height="65" border="0" bordorcolor="blue">
  <tr>
    <td height="40" align="center" valign="middle" bordercolor="white" bgcolor="blue"> <div align="left" class="style2"><span class="style3"><font size="30">&nbsp;&nbsp;&nbsp;Patient</span></div></td>
  </tr>
</table>



<table border="0" bgcolor="blue">

<tr>
<td><ul><li><a href="searchdoctor.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Search Doctor</small></center></a></li></ul></td>
<td><ul><li><a href="patient1disp.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>View Appointment</small></center></a></li></ul></td>
<td><ul><li><a href="patient1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Take Appointment </small></center></a></li></ul></td>
<td><ul><li><a href="mainframe1.php"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b>Log out</small></center></a></li></ul></td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
<td><ul><li><a href="#"><font size="6"  align="center" style="background-size:cover;float:center;"><center><small><b></small></center></a></ul></li>
</td>
</tr>

</table>



<table border="0" align="center">
<tr>
<td height="0" width="600"><img src="health_care_system.jpg" width="500" height="500">
</td>

<td width="1500" height="0"  bgcolor="blue" bordercolor="white">
<?php
 $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die("Error ");
  }
  mysql_query("use rbnb");
$pn=$_POST['t1'];
$id=$_POST['t8'];
$dn=$_POST['t2'];
$f=0;
   $sql="select * from takeapp";
    $res=mysql_query($sql);
echo"<table border='1' bordercolor='white' align='center' width='80%'>";
echo"";
echo"<tr><font size='8' color='white' align='center'><b><center><br>Appointment Details:</b></font></tr>";

    while($row=mysql_fetch_array($res))
   {
    if($row['pname']==$pn&&$row['did']==$id&&$row['dname']==$dn)
     {
            
                  $v1=$row['pname']; 
                  $v2=$row['did'];
                  $v3=$row['dname'];   
                  $v4=$row['sym'];
                  $v5=$row['dt'];
                  $f=1;
         }  
}
if($f==1)
{
  echo"<tr><th><font color='white' size='5'>Patient name<th><font color='white' size='5'>Docor Id<th><font color='white' size='5'>Doctor name<th><font color='white' size='5'>Symptoms<th><font color='white' size='5'>Date:Time</th></tr>";


  echo"<tr><td><font color='white' size='5' ><center>".$v1."<td><font color='white' size='5'><center>".$v2."</td><td><font color='white' size='5'><center>".$v3."</td><td><font color='white' size='5'><center>".$v4."</td><td><font color='white' size='5'><center>".$v5."</font></td></tr><br>";
}
else
{
    echo"<font color='white' size='6' align='center'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;There is no appointment";
}
echo"</table>";
?>
</td>

<td width="500" height="300">
<img src="doctor-appointment-concealed-carry.jpg" width="200" height="500">



</td>


</tr>
</table>
<table border="0">
<tr>
<td bgcolor="blue" height="50" width="1500"><font size="3" color="white">&nbsp;&nbsp;&nbsp;@doctorappointmentsystem</td>
</tr>
</table>
</form>
</body>
</html>