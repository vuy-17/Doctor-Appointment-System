<!DOCTYPE html>
<html>

<head>
<style>

.a{
     background-image:linear-gradient(rgba(1,0,0,0.4),rgba(0,0,0,0.4)),url(images1.jpg);
 
    width:840px;
  height:490px;
    background-size:cover;
    background-position:center;
}

.form{
position:relative;
z-index:1;
background:rgba(7,40,190,0.8);
max-width:370px;
margin:0 auto 10px;
padding:50px;
text-align:center;
}
select{
   width:100%;
   padding:5px 15px;
  border:none;
border-radius:10px;
background-color:"white";
}
.form input{
 font-family:"Roboto",sans-serif;
outline:0;
background:#f2f2f2;
width:45%;
border=0;
margin:0 0 10px;
padding:10px;
box-sizing:bordor-box;
font-size:20px;
}
.form button{
 font-family:"Roboto",sans-serif;
text-transform:uppercase;
outline:0;
background:#4CAF50;
width:100%;
border=0;
margin:5 5 100px;
padding:10px;
box-sizing:bordor-box;
color:#FFFFFF;
font-size:20px;
cursor:pointer;
}

ul{
list-style-type:none;
margin:0px;
padding:0px;
width:250px;
background-color:#0000FF;
text-transform:uppercase;
}
li>a{
display:block;
color:white;
padding:30px 18px;
text-decoration:none;
}
li>a:hover{
background-color:white;
color:blue;
}

<!--
.style2 {
color: #FFFFFF
}
.style3 {
font-size: xx-large;
 font-weight: bold;
 font-family: Georgia, "Times New Roman", Times, serif;
  
}
.>


div.img{
     margin:5px;
     float:center;
       width:180px;
    }
h1{
        text-align:center;
        line-height:1.2;
}

img{
  width:100%;
}
</style>
</head>


<body background="">
<form method="POST" action="login3.php">
<div class="img">
<img src="AAEAAQAAAAAAAAe9AAAAJDNjZTkzMjVlLWYyMGUtNGMzZi05ZGNmLTE3NDcwNzA4MzNiYw.jpg" align="center" style="background-size:cover;float:center;width:1519px; height:200px;">



<table width="100%" height="88" border="0" bordorcolor="blue">
  <tr>
    <td height="85" align="center" valign="middle" bordercolor="white" bgcolor="blue"> <div align="center" class="style2"><span class="style3"><font size="30">Doctor &nbsp;&nbsp;&nbsp;Appointment &nbsp;&nbsp;&nbsp;System</span></div></td>
  </tr>
</table>







<div>
<table border="0" >

<tr>
<td>
<ul>
<li><a href="home.php"><font size="6"  align="center" style="background-size:cover;float:center;" ><center><small><b>HOME</small></center></a></li>
<li><a href="mainframe1.php"><font size="6"  align="center" style="background-size:cover;float:center;" ><center><small><b>LOGIN</small></center></a></li>
<li><a href="aboutus.php"><font size="6"  align="center" style="background-size:cover;float:center;" ><center><small><b>ABOUT US</small></center></a></li>
<li><a href="feedback.php"><font size="6"  align="center" style="background-size:cover;float:center;" ><center><small><b>FEEDBACK</small></center></a></li>
<li><a href="mainframe1.php"><font size="6"  align="center" style="background-size:cover;float:center;" ><center><small><b>LOGOUT</small></center></a></li>

</ul>
</div>
</td>
<td  height="350" width="800"><div class="a">&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<br>
<br>
<br>
<br><div class="login-page">
<div class="form">
<form class="register-form">

<?php

 $con=mysql_connect("localhost","root","");
  if(!$con)
  {
     die('Error '.mysql_error());
  }
  mysql_select_db('rbnb',$con) or die(mysql_error($con));

   $name=$_POST["t1"];
   $emailid=$_POST["t2"];
   $feedback=$_POST["t3"];
  mysql_query("insert into  feedback values(NULL,'".$name."','".$emailid."','".$feedback."')");
echo"<br><br><br><br><font size='7' color='white' align='center'>Feedback send</font>";  

?>



</div>


</div>
</div>

</form>
</td>
<td  height="200" width="200" bordercolor="white" > <img src="images.png" align="top" style="background-size:cover;float:center;width:400px; height:250px;"><img src="health_care_system.jpg" align="bottom" style="background-size:cover;float:center;width:400px; height:230px;">
</td>
</tr>
</table>
<table border="0">
<tr>
<td bgcolor="blue" height="50" width="1500"><font size="3" color="white">&nbsp;&nbsp;&nbsp;@doctorappointmentsystem</td>
</tr>
</table>
</form>
</body>


</html>

