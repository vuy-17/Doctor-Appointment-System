<html>
 <style>
<head>
.form button{
 font-family:"Roboto",sans-serif;
text-transform:uppercase;
outline:0;
background:#4CAF50;
width:100%;
border=0;
margin:5 5 100px;
padding:10px;
box-sizing:bordor-box;
color:#FFFFFF;
font-size:30px;
cursor:pointer;
}

select{  width:100%;
               padding:5px 15px;
  border:none;
border-radius:10px;
background-color:"white";
}
body{
     background-image:linear-gradient(rgba(1,0,0,0.4),rgba(0,0,0,0.4)),url(images1.jpg);
  background-size:cover;
    background-position:center;
}
.form{
position:relative;
z-index:1;
background:rgba(7,40,195,0.8);
max-width:600px;
margin:50 auto 100px;
padding:50px;
text-align:center;
}
.form input{
 
font-family:"Roboto",sans-serif;
outline:1;
background:#f2f2f2;
width:60%;
border=0;
margin:0 0 20px;
padding:15px;
box-sizing:bordor-box;
font-size:14px;
}
 </style>
</head>
<body>
<form method="POST">
<font size="20' color="white">Register here:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font><br>
<tr><td><font size="5" color="white">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Account type:<input type="text" name="n"></td></tr><br>
<input type="submit" value="submit">
</form>
</body>
<?php
$t=$_POST['n'];
if($t=='admin')
{
 echo"<body>";
echo"<div class='login-page'>";
echo"<div class='form'>";
echo"<form class='register-form'>";
echo"<font size='20' color='white'>Admin Registration</font>";
echo"<table border='0'>";
echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;First name:<input type='text' name='n1'></td></tr>";

echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Last name:<input type='text' name='n2'></td></tr><br>";

echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address:<textarea rows='4' cols='30' name='ta'></textarea></td></tr><br>";
echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email id:<input type='text' name='name'></td></tr><br>";

echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone no:<input type='text' name='name'></td></tr><br>";
echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password:<input type='password' name='name'></td></tr><br>";



echo"</table>";
echo"<table bordor='0'><tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='submit'></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;   <input type='reset'></td></tr></table>";
echo"</div>";
echo"</div>";
echo"</div>";

echo"</form>";
echo"</body>";
}


if($t=='doctor')
{
echo"<body>";
echo"<div class='login-page'>";
echo"<div class='form'>";
echo"<form class='register-form'>";
echo"<form method='POST' action='admin1.html'>";                         

echo"<font size='20' color='white'>Doctor Registration</font>";
echo"<table border='0'>";
echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;First name:<input type='text' name='n1'></td></tr>";

echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Last name:<input type='text' name='n2'></td></tr><br>";

echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address:<textarea rows='4' cols='30' name='ta'></textarea></td></tr><br>";
echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email id:<input type='text' name='name'></td></tr><br>";

echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone no:<input type='text' name='name'></td></tr><br>";
echo"<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password:<input type='password' name='name'></td></tr><br>";



echo"</table>";
echo"<table bordor='0'><tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='submit'></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;   <input type='reset'></td></tr></table>";
echo"</div>";
echo"</div>";
echo"</div>";

echo"</form>";
echo"</body>";
}
?>
echo"</body>";
echo"</html>";

