<html>
<style>
.form button{
 font-family:"Roboto",sans-serif;
text-transform:uppercase;
outline:0;
background:#4CAF50;
width:100%;
border=0;
margin:5 5 100px;
padding:10px;
box-sizing:bordor-box;
color:#FFFFFF;
font-size:30px;
cursor:pointer;
}

select{  width:90%;
               padding:5px 15px;
  border:none;
border-radius:10px;
background-color:"white";
}
body{
     background-image:linear-gradient(rgba(1,0,0,0.4),rgba(0,0,0,0.4)),url(images1.jpg);
  background-size:cover;
    background-position:center;
}
.form{
position:relative;
z-index:1;
background:rgba(7,40,195,0.8);
max-width:600px;
margin:35 auto 100px;
padding:50px;
text-align:center;
}
.form input{
 font-family:"Roboto",sans-serif;
outline:1;
background:#f2f2f2;
width:60%;
border=0;
margin:0 0 20px;
padding:15px;
box-sizing:bordor-box;
font-size:14px;
}

</style>
 <body>
     <div class='login-page'>
     <div class='form'>
          <form method="post" class='register-form' action="doctordb.php">

    <font size='20' color='white' >Doctor Registration</font>    
<table border='0'>

<tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<input type='text' name='t1' required></td></tr>
     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-mail id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='t2' pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required></td></tr><br>

     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea rows='4' cols='30' name='t3' required></textarea></td></tr><br>
     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;City:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='t4' required></td></tr><br>

     <tr><td><font size='5' color='white'>Hospital name:  <input type='text' name='t12' required></td></tr><br>




     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Birth date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='t5' required></td></tr><br>


     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone no:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='t6' pattern="[0-9]{10}" title="should be 10digits" required></td></tr><br>

     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Specialist:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='t7'></td></tr><br>
     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Experiance:&nbsp;&nbsp;<input type='text' name='t8'></td></tr><br>



     <tr><td><font size='5' color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='password' name='t9' pattern=".{6,}" title="6 or more charcters required" required></td></tr><br>

<tr><td><font size='5' color='white' align="center">&nbsp;&nbsp;&nbsp;&nbsp;Avialable time:<br>&nbsp;&nbsp;&nbsp;&nbsp;From:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t10"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t11"></td></tr>


     </table>
     <table bordor='0' align="center"><tr><td align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='submit'></td><td align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type='reset' ></td></tr></table>
     </div>
</div>
</div>

</form>
</body>
</html>